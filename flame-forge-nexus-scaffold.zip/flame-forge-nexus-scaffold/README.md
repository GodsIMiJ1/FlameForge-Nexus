# Flame Forge Nexus — Scaffold

This scaffold provides the skeleton for implementing the **AUGMENT_DIRECTIVE_v2**.
It includes a minimal server, node/plugin interfaces, operator console stubs,
and SQL for logging tables.

## Quick Start
1. Copy `.env.example` to `.env.local` and fill in secrets.
2. `docker compose up -d` (to launch Postgres + pgAdmin).
3. Run the SQL in `scripts/sql/create_tables.sql`.
4. Implement services under `src/server/services/`.
5. Start dev server (wire to your preferred framework).

## Structure
- `src/server`: API routes, node runtime, registry, services
- `src/workbench`: Flow editor (XYFlow) stubs
- `src/console`: Operator Console stubs (Executions, Interactions)
- `src/server/plugins`: Plugin SDK loading
- `scripts/sql`: schema for interactions and executions tables

This is intentionally minimal—Augment fills in the details.
