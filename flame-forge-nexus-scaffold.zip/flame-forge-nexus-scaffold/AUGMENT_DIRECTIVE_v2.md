# ⚔️ Augment Directive — Flame Forge Nexus (v0.2 → v0.3, Enhanced Edition)

## Objective
Transform Flame Forge Nexus into a sovereign AI workflow automation platform, capable of executing complex multi-agent workflows with persistence, escalation, extensibility, and operator visibility.  

---

## Phase I — Core Finalization
- **Agent Nodes**  
  - Define schema: `id, name, system_prompt, context_sources, embeddings, metadata`.  
  - `metadata` captures runtime stats (performance, invocation counts).  
  - Explicitly define multi-turn conversation handling and context update strategies.  

- **Decision Nodes**  
  - Add conditional branching: regex evaluation, LLM classification, and custom scripting (JavaScript snippets).  
  - Include node-level audit logs for tracking decision outcomes across runs.  

- **Memory Nodes**  
  - Log interactions to Postgres (`interactions`, `executions`).  
  - Add pgvector support for embedding-based recall.  
  - Create periodic backup routines (snapshots, exports).  

- **Tool Nodes**  
  - Slack (send channel message).  
  - Gmail/SMTP (send escalation email).  
  - Google Calendar (create event).  
  - Twilio (ingest transcripts via webhook).  
  - External Tool Registration: support REST, GraphQL, Webhooks.  
  - Add health check endpoints for integration status.  

- **Execution Engine**  
  - Refactor runtime: all nodes as async promises.  
  - Add retry, error handling, and logging to `executions` table.  
  - Support batch execution (parallel runs).  
  - Define replay policies (auto/manual).  

**Deliverable:** Bianca’s healthcare workflow can be fully rebuilt inside Nexus without external Lindy.  

---

## Phase II — Operator Console
- **Execution Viewer**  
  - Display executions with filters (agent, status, urgency).  
  - Expand to view node path + outputs.  
  - Add live-update mode to monitor running workflows.  
  - Export execution trails to CSV/PDF.  

- **Search Logs**  
  - Build UI over `bianca_interactions` with filters.  
  - Support custom tags/labels for grouping.  
  - Timeline views and analytics for efficiency tracking.  

- **Replay Execution**  
  - Button to rerun workflow with original input.  
  - Allow cloning/modification of input before rerun.  
  - Support partial replays (from a decision node onward).  

**Deliverable:** Operator Console becomes a true Command Deck for live oversight.  

---

## Phase III — Plugin SDK
- **Node Registry**  
  - Define universal node interface:  
    ```ts
    interface ForgeNode {
      id: string
      type: "agent" | "tool" | "data" | "decision" | "memory"
      inputs: Record<string, any>
      outputs: Record<string, any>
      execute(inputs: any, ctx: ForgeContext): Promise<any>
    }
    ```  
  - Document versioning and dependency management.  

- **Plugin Loader**  
  - Autoload plugins from `/plugins` folder.  
  - Validate via manifest (author, version, capabilities).  
  - Support plugin lifecycle hooks (init, unload).  

- **Example Plugins**  
  - `KnowledgeBaseNode` → text/FAQ lookup.  
  - `VectorSearchNode` → embeddings + pgvector query.  
  - `CalendarNode` → event scheduling.  
  - `CustomScriptNode` → programmable node for advanced users.  
  - Enable automatic discovery of updates (e.g., GitHub releases).  

**Deliverable:** New nodes can be added as plugins without touching the core engine.  

---

## Phase IV — Sovereign Migration
- **Database**  
  - Mirror schema to GhostVault (Postgres + pgvector).  
  - Migration verification tools (schema diff, data validation).  
  - Staged migrations with rollback capability.  

- **Auth**  
  - Replace Supabase with GhostVault Hanko/Keycloak.  
  - Provide migration guides.  
  - Add SSO and granular role-based policies.  

- **Storage**  
  - Redirect storage to GhostVault MinIO.  
  - Add redundancy + cross-region support for disaster recovery.  

**Deliverable:** Nexus runs fully sovereign under Empire control.  

---

## Phase V — Future Enhancements
- **Workflow Templates**  
  - Publish/import templates directly in UI.  
  - Include metadata (author, tags).  
  - Support community contributions + peer review.  

- **Multi-Agent Collaboration**  
  - Middleware nodes for negotiation, consensus, voting between agents.  

- **Scheduling Engine**  
  - Support cron, interval, and event-driven triggers (webhooks, DB updates).  

- **UI Enhancements**  
  - Drag-and-drop KB docs and other files (audio, image, video) for multimodal workflows.  

---

## General Recommendations
- **Testing:** Automated integration + E2E tests for all node types, plugins, migrations.  
- **Documentation:** Developer + operator guides for SDK, plugin interfaces, migration steps.  
- **Security:** Regular security audits and threat modeling for migration.  
- **Community:** Beta program for plugin developers and enterprise migration testers.  

---

## Development Protocol
1. Implement each phase incrementally.  
2. Commit changes with scroll-tag prefixes: `[Phase-I]`, `[Phase-II]`, etc.  
3. Verify deliverables by reconstructing Bianca’s workflow and testing end-to-end.  
4. Archive immutable audit logs for reproducibility.  

