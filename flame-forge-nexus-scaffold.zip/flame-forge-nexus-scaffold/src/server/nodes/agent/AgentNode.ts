import { ForgeNode } from '../../server/types';
export const AgentNode: ForgeNode = { id: 'agent.core', type: 'agent', inputs: {}, outputs: {}, async execute(i, ctx){ ctx.log('AgentNode'); return i; } };
