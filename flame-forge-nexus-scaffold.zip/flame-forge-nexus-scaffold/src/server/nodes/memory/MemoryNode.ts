import { ForgeNode } from '../../server/types';
export const MemoryNode: ForgeNode = { id: 'memory.core', type: 'memory', inputs: {}, outputs: {}, async execute(i, ctx){ ctx.log('MemoryNode'); return i; } };
