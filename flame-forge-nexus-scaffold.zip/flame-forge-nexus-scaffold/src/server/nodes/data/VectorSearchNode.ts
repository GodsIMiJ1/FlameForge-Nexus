import { ForgeNode } from '../../server/types';
export const VectorSearchNode: ForgeNode = { id: 'data.vector', type: 'data', inputs: {}, outputs: {}, async execute(i, ctx){ ctx.log('VectorSearchNode'); return i; } };
