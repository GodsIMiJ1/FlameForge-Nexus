import { ForgeNode } from '../../server/types';
export const TwilioNode: ForgeNode = { id: 'tool.twilio', type: 'tool', inputs: {}, outputs: {}, async execute(i, ctx){ ctx.log('TwilioNode'); return i; } };
