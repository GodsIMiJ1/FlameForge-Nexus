import { ForgeNode } from '../../server/types';
export const CalendarNode: ForgeNode = { id: 'tool.calendar', type: 'tool', inputs: {}, outputs: {}, async execute(i, ctx){ ctx.log('CalendarNode'); return i; } };
