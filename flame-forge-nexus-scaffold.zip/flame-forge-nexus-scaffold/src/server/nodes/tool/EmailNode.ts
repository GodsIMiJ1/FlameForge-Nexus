import { ForgeNode } from '../../server/types';
export const EmailNode: ForgeNode = { id: 'tool.email', type: 'tool', inputs: {}, outputs: {}, async execute(i, ctx){ ctx.log('EmailNode'); return i; } };
