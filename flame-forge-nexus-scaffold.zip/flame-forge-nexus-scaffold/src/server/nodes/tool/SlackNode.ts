import { ForgeNode } from '../../server/types';
export const SlackNode: ForgeNode = { id: 'tool.slack', type: 'tool', inputs: {}, outputs: {}, async execute(i, ctx){ ctx.log('SlackNode'); return i; } };
