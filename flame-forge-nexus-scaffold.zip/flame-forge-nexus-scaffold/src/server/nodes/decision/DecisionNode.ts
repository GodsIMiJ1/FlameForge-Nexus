import { ForgeNode } from '../../server/types';
export const DecisionNode: ForgeNode = { id: 'decision.core', type: 'decision', inputs: {}, outputs: {}, async execute(i, ctx){ ctx.log('DecisionNode'); return i; } };
