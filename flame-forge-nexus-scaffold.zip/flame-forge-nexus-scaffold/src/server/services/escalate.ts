import { WebClient } from '@slack/web-api';
import nodemailer from 'nodemailer';

const slack = new WebClient(process.env.SLACK_BOT_TOKEN);

export async function escalate(msg: any) {
  // Slack alert
  if (process.env.SLACK_BOT_TOKEN && process.env.SLACK_ALERT_CHANNEL) {
    await slack.chat.postMessage({
      channel: process.env.SLACK_ALERT_CHANNEL,
      text: `🚨 URGENT CASE\nFrom: ${msg.sender_name} ${msg.sender_email ?? ''} ${msg.phone ?? ''}\n${msg.message}\nSource: ${msg.thread_url ?? 'n/a'}`
    }).catch(() => {});
  }

  // Email alert
  if (process.env.SMTP_HOST && process.env.SMTP_USER && process.env.SMTP_PASS && process.env.ALERT_EMAIL_TO) {
    const tx = nodemailer.createTransport({
      host: process.env.SMTP_HOST,
      port: +(process.env.SMTP_PORT || 587),
      secure: false,
      auth: { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS }
    });
    await tx.sendMail({
      from: process.env.ALERT_EMAIL_FROM || 'Bianca <no-reply@localhost>',
      to: process.env.ALERT_EMAIL_TO,
      subject: `[URGENT] ${msg.subject || 'Patient alert'}`,
      text: `Urgent case:\n\n${JSON.stringify(msg, null, 2)}`
    }).catch(() => {});
  }
}
