export async function scheduleIfAsked(msg: any, answer: { text: string }): Promise<{ link: string } | null> {
  // Stub: detect "appointment" terms, then call Google Calendar.
  const wantsAppt = /(book|schedule|appointment|reschedule)/i.test(msg.message || '');
  if (!wantsAppt) return null;
  // TODO: integrate Google Calendar with service account
  return { link: 'https://calendar.google.com/event?mock' };
}
