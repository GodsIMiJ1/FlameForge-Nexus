import { Pool } from 'pg';
const pool = new Pool({ connectionString: process.env.DATABASE_URL });

export async function logInteraction(row: any) {
  const q = `
    CREATE TABLE IF NOT EXISTS bianca_interactions (
      id BIGSERIAL PRIMARY KEY,
      timestamp timestamptz DEFAULT now(),
      channel TEXT,
      sender_name TEXT,
      sender_email TEXT,
      phone TEXT,
      subject TEXT,
      message TEXT,
      intent TEXT,
      urgency TEXT,
      status TEXT,
      action_taken TEXT,
      calendar_event_link TEXT,
      escalated_to TEXT,
      notes TEXT,
      thread_url TEXT
    );
  `;
  await pool.query(q);

  const insert = """
    INSERT INTO bianca_interactions
    (channel, sender_name, sender_email, phone, subject, message, intent, urgency, status, action_taken, calendar_event_link, escalated_to, notes, thread_url)
    VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14)
  """;
  const vals = [
    row.channel, row.sender_name, row.sender_email, row.phone, row.subject, row.message,
    row.intent, row.urgency, row.status, row.action_taken, row.calendar_event_link,
    row.escalated_to, row.notes, row.thread_url
  ];
  await pool.query(insert, vals);
}
