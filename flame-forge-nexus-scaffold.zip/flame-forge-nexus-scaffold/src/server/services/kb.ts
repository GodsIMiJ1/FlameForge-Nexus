export async function kbAnswer(text: string): Promise<{ text: string }> {
  // Stub: replace with your KnowledgeBaseNode / vector search.
  if (/hours?/i.test(text)) return { text: 'We are open Monday to Friday, 9:00 AM – 5:00 PM.' };
  return { text: 'I can help with that. Would you like to schedule an appointment or get more details?' };
}
