export interface ForgeContext {
  executionId: string;
  env: Record<string, string | undefined>;
  log: (msg: string) => void;
}

export interface ForgeNode {
  id: string;
  type: 'agent' | 'tool' | 'data' | 'decision' | 'memory';
  inputs: Record<string, any>;
  outputs: Record<string, any>;
  execute(inputs: any, ctx: ForgeContext): Promise<any>;
}
