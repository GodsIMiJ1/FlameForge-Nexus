import { ForgeNode } from '../types';

const registry: Record<string, ForgeNode> = {};

export function registerNode(node: ForgeNode) {
  registry[node.id] = node;
}

export function getNode(id: string) {
  return registry[id];
}

export function listNodes() {
  return Object.values(registry);
}
