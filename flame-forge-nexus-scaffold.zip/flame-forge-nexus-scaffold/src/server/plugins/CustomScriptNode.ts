import { ForgeNode } from '../types';
export const CustomScriptNode: ForgeNode = { id: 'plugin.customscript', type: 'decision', inputs: {}, outputs: {}, async execute(i, ctx){ ctx.log('CustomScriptNode'); return i; } };
