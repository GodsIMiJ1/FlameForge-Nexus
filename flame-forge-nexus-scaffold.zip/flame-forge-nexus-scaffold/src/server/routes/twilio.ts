import type { Request, Response } from 'express';
import axios from 'axios';

export async function twilioWebhook(req: Request, res: Response) {
  const { From, TranscriptionText, CallSid } = req.body || {};
  await axios.post((process.env.PUBLIC_URL || '') + '/api/ingest', {
    channel: 'twilio-voice',
    sender_name: From,
    phone: From,
    subject: `Call ${CallSid}`,
    message: TranscriptionText,
    thread_url: `twilio:call:${CallSid}`
  }).catch(() => {});
  res.status(200).end();
}
