import type { Request, Response } from 'express';
import { logInteraction } from '../services/log';
import { escalate } from '../services/escalate';
import { kbAnswer } from '../services/kb';
import { scheduleIfAsked } from '../services/calendar';

export async function ingest(req: Request, res: Response) {
  const msg = req.body || {};
  const regex = new RegExp(process.env.EMERGENCY_REGEX || '(?!)', 'i');
  const isUrgent = regex.test(msg.message || '');

  if (isUrgent) {
    await logInteraction({ ...msg, urgency: 'High', status: 'Escalated' });
    await escalate(msg);
    return res.json({ 
      reply: 'If you are experiencing a medical emergency, call 911 immediately. I’ve escalated this to a human responder.' 
    });
  }

  const answer = await kbAnswer(msg.message || '');
  const scheduled = await scheduleIfAsked(msg, answer);

  await logInteraction({
    ...msg,
    urgency: 'Normal',
    status: scheduled ? 'Scheduled' : 'Resolved',
    action_taken: scheduled ? 'Calendar Event' : 'Answer Sent',
    calendar_event_link: scheduled?.link
  });

  return res.json({ reply: answer.text, calendar: scheduled });
}
