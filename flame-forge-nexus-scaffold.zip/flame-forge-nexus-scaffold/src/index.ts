import express from 'express';
import { ingest } from './server/routes/ingest';
import { twilioWebhook } from './server/routes/twilio';

const app = express();
app.use(express.json());

app.post('/api/ingest', ingest);
app.post('/webhooks/twilio', twilioWebhook);

const port = process.env.PORT || 5173;
app.listen(port, () => {
  console.log(`[Forge] API listening on http://localhost:${port}`);
});
