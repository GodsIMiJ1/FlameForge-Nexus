export default function ExecutionTable(){return <div>Table (stub)</div>}
