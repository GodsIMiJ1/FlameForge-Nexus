export default function LogFilters(){return <div>Filters (stub)</div>}
