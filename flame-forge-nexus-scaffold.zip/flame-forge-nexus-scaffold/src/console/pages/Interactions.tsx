export default function Interactions(){return <div>Interactions (stub)</div>}
