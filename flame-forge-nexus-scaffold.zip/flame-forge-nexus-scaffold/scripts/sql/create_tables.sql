-- Core logging tables
CREATE TABLE IF NOT EXISTS bianca_interactions (
  id BIGSERIAL PRIMARY KEY,
  timestamp timestamptz DEFAULT now(),
  channel TEXT,
  sender_name TEXT,
  sender_email TEXT,
  phone TEXT,
  subject TEXT,
  message TEXT,
  intent TEXT,
  urgency TEXT,
  status TEXT,
  action_taken TEXT,
  calendar_event_link TEXT,
  escalated_to TEXT,
  notes TEXT,
  thread_url TEXT
);
CREATE INDEX IF NOT EXISTS idx_bianca_urgency ON bianca_interactions(urgency);
CREATE INDEX IF NOT EXISTS idx_bianca_status ON bianca_interactions(status);

CREATE TABLE IF NOT EXISTS executions (
  id BIGSERIAL PRIMARY KEY,
  created_at timestamptz DEFAULT now(),
  workflow_id TEXT,
  agent_id TEXT,
  status TEXT,
  input JSONB,
  output JSONB,
  error TEXT
);
CREATE INDEX IF NOT EXISTS idx_exec_status ON executions(status);
